$(document).ready(function () {

    $('.banner-slider').slick({
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        speed: 800,
        autoplay: true,
        autoplaySpeed: 3000,
        fade: true,
        cssEase: 'ease-in-out',
        arrows: true,
        dots: true,
        pauseOnHover: false
    });

    $('.latest-intro').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 500,
        arrows: true,
        dots: false,

        responsive: [
            {
                breakpoint: 1025,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    $('.exhibition-slider').slick({
        infinite: true,
        centerMode: true,
        centerPadding: '0px',
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        speed: 500,
        autoplay: true,
        autoplaySpeed: 3000,

        responsive: [
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 3,
                    centerMode: true,
                    centerPadding: '0px',
                    arrows: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    centerMode: true,
                    centerPadding: '0px',
                    arrows: true
                }
            },
            {
                breakpoint: 568,
                settings: {
                    slidesToShow: 1,
                    centerMode: true,
                    centerPadding: '40px',
                    arrows: true
                }
            }
        ]
    });

    var productSlider = $('.product-slider');

    productSlider.slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        arrows: true,
        dots: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        speed: 500,

        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 4
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });

    $('.filter-btn').on('click', function () {

        $('.filter-btn').removeClass('active');
        $(this).addClass('active');

        var filter = $(this).data('filter');

        productSlider.slick('slickUnfilter');

        if (filter !== 'all') {
            productSlider.slick('slickFilter', '.' + filter);
        }

    });

    function initCollectionSlider() {

        var collectionGrid = $('.collection-grid');

        if ($(window).width() <= 567) {

            if (!collectionGrid.hasClass('slick-initialized')) {

                collectionGrid.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    infinite: true,
                    autoplay: true,
                    autoplaySpeed: 3000,
                    speed: 500,
                    arrows: true,
                    dots: false
                });

            }

        } else {

            if (collectionGrid.hasClass('slick-initialized')) {
                collectionGrid.slick('unslick');
            }

        }
    }

    initCollectionSlider();

    var resizeTimer;

    $(window).on('resize', function () {

        clearTimeout(resizeTimer);

        resizeTimer = setTimeout(function () {
            initCollectionSlider();
        }, 200);

    });

    $('.logo-slider').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        speed: 600,
        infinite: true,
        arrows: false,
        dots: false,
        pauseOnHover: true,

        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 568,
                settings: {
                    slidesToShow: 2
                }
            }
        ]
    });

    $('.menu-toggle').on('click', function () {

        $('.header-nav-wrapper').toggleClass('menu-open');

    });


    $('.has-mega-menu > a').on('click', function (e) {

        if ($(window).width() <= 1024) {

            e.preventDefault();

            $(this)
                .parent()
                .toggleClass('dropdown-open');

        }

    });

});